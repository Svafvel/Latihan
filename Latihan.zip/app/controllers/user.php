<?php 

class user extends Controller{

    public function index(){

        if ($_SESSION['login'] == true && $_SESSION['GrantPrivilages'] == 'user'){

            $data['allarticle']= $this->model('article_model')->getAllArticle();
            $data['allcatagory']= $this->model('article_model')->getAllCatagory();

            $data['judul'] = 'User';
            $this->view('templates/header', $data);
            $this->view('user/index', $data);
            $this->view('templates/footer', $data);
            
            // $_SESSION['login'] = false;

        }else {

            header('Location:'.BASEURL);

        }


    }

    public function getArticle($keyword=null){

        $data['allarticle']= $this->model('article_model')->getArticle($keyword);
        $data['allcatagory']= $this->model('article_model')->getAllCatagory();
        $data['getCatagory']= $this->model('article_model')->getCatagory($keyword);
        
        $this->view('user/searchindex', $data);

    }

    public function insertComment($iduser, $idarticle){

        if ($this->model('article_model')->insertComment($iduser,$idarticle, $_POST) > 0 ){

            header('Location: '. BASEURL . $_SESSION['GrantPrivilages'] . '/detail/' . $idarticle);
            exit;

        }
        
    }


    public function detail($id){

        $data['allarticle']= $this->model('article_model')->getAllArticleById($id);
        $data['allInfoComment'] = $this->model('article_model')->getInfoComment($id);

        $data['judul'] = 'Article Detail';
        $this->view('templates/header', $data);
        $this->view('user/detail', $data);
        $this->view('templates/footer', $data);

    }

    public function profile(){

        $data['judul'] = 'Profile';
        $this->view('templates/header', $data);
        $this->view('user/profile', $data);
        $this->view('templates/footer', $data);

    }

    public function change_password(){

        $data['judul'] = 'Change Password';
        $this->view('templates/header', $data);
        $this->view('user/change_password', $data);
        $this->view('templates/footer', $data);

    }

    public function changePassword($id){


        if ($this->model('user_model')->changePassword($id, $_POST) > 0 ){

            header('Location: '. BASEURL);
            exit;

        }else {

            header('Location: '.BASEURL.'user/change_password');
            exit;
        }

    }

    public function changeProfile($id){

        if ($this->model('user_model')->changeProfile($id, $_POST) > 0 ){

            header('Location: '. BASEURL);
            exit;

        }else {

            header('Location: '.BASEURL.'user/change_password');
            exit;
        }

    }





}