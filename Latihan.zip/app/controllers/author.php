<?php 

class author extends Controller {

    public function index(){

        if ($_SESSION['login'] == true && $_SESSION['GrantPrivilages'] == 'author'){

            $data['judul'] = "Author";
            $this->view('templates/header', $data);
            $this->view('author/index');
            $this->view('templates/footer', $data);

            $_SESSION['login'] = false;

        }else {

            header('Location: '.BASEURL);

        }



    }

}