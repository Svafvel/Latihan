<?php 

class editor extends Controller {

    public function index(){

        if ($_SESSION['login'] == true && $_SESSION['GrantPrivilages'] == 'editor'){

            $data['judul'] = "Editor";
            $this->view('templates/header', $data);
            $this->view('editor/index');
            $this->view('templates/footer', $data);

            $_SESSION['login'] = false;

        }else {

            header('Location: '.BASEURL);

        }



    }

}