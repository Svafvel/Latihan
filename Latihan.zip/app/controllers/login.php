<?php

class login extends Controller{

    public function index(){

        $data['judul'] = 'LOGIN';

        $this->view('templates/header', $data);
        $this->view('login/index', $data);
        $this->view('templates/footer', $data);
    }

    public function validasiLogin(){


        if ($this->model('user_model')->validasiLogin($_POST) != null) {

            $_SESSION['login'] = true;
            $dataUSER = $this->model('user_model')->validasiLogin($_POST);

            $_SESSION['GrantPrivilages'] = strtolower($dataUSER['GrantPrivilages']);
            $_SESSION['user'] = $dataUSER['ID_Users'];
            header('Location:'. BASEURL .strtolower($dataUSER['GrantPrivilages']));
            
            exit();

        } else {

            header('Location: ' . BASEURL);
        }
    }


    public function reset_password(){

        $data['judul'] = 'Reset Password';
        $this->view('templates/header', $data);
        $this->view('reset_password/index');
        $this->view('templates/footer', $data);
    }

    public function Goreset_password(){

        if ($this->model('user_model')->sendMailChangePass($_POST) != Null){

            $this->view('templates/header', $data);
            $this->view('reset_password/index');
            $this->view('templates/footer', $data);

        }

    }

}
