<?php
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require 'vendor/autoload.php';

class Mailer {

    public function __construct(){

        // Instantiation and passing `true` enables exceptions
        $this->mail = new PHPMailer(true);

    }

    public function sendMail($EmailPenerima, $codeVerifikasi){

        try {
            //Server settings
            // $mail->SMTPDebug = 2;                                       // Enable verbose debug output
            $mail->isSMTP();                                            // Set mailer to use SMTP
            $mail->Host       = 'smtp.gmail.com';  // Specify main and backup SMTP servers
            $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
            $mail->Username   = EMAIL;                     // SMTP username
            $mail->Password   = PASS;                               // SMTP password
            $mail->SMTPSecure = 'tls';                                  // Enable TLS encryption, `ssl` also accepted
            $mail->Port       = 587;                                    // TCP port to connect to

            //Recipients
            $this->mail->setFrom($EmailPenerima, 'Admin Website');
            // $this->mail->addAddress('arexmint@gmail.com', 'Admin Website');     // Add a recipient
            // $mail->addAddress('ellen@example.com');               // Name is optional
            // $mail->addReplyTo('info@example.com', 'Information');
            // $mail->addCC('cc@example.com');
            // $mail->addBCC('bcc@example.com');

            // Attachments
            // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
            // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

            // Content
            $this->mail->isHTML(true);                                  // Set email format to HTML
            $this->mail->Subject = 'Verifikasi Change Password';
            $this->mail->Body    = "You Have Requested Change Password ... <br><br>
                            if it is indeed you please, follow this link to continue changing your password ... <br><br><br>

                            $codeVerifikasi ... <br><br><br>

                            Thank you Regards Admin... :)";
            $this->mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

            $this->mail->send();

            return $codeVerifikasi;

        } catch (Exception $e) {

            return Null;

        }
    }



}