<?php 


class Article_model {

    private $db;

    public function __construct(){

        $this->db = new Database;

    }

    public function getAllCatagory(){

        $this->db->query("SELECT DISTINCT Catagory.Catagory FROM Catagory INNER JOIN Article ON Catagory.ID_Catagory=Article.ID_Catagory");
        return $this->db->resultSet();

    }

    public function getAllArticle(){

        $this->db->query("SELECT Article.ID_Article, Article.Title, Users.Name, Catagory.Catagory, SubCatagory.SubCatagory FROM Article INNER JOIN Catagory ON Catagory.ID_Catagory=Article.ID_Catagory INNER JOIN SubCatagory ON Article.ID_SubCatagory=SubCatagory.ID_SubCatagory INNER JOIN Users ON Article.ID_Users=Users.ID_Users");
        return $this->db->resultSet();

    }

    public function getArticle($keyword){

        $this->db->query("SELECT  Article.ID_Article, Article.Title, Users.Name, Catagory.Catagory, SubCatagory.SubCatagory, Article.Article, Article.Attachment, Article.DateCreate, Article.DateUpdated FROM Article INNER JOIN Catagory ON Catagory.ID_Catagory=Article.ID_Catagory INNER JOIN SubCatagory ON Article.ID_SubCatagory=SubCatagory.ID_SubCatagory INNER JOIN Users ON Article.ID_Users=Users.ID_Users WHERE ( Title LIKE :keyword OR Catagory LIKE :keyword OR SubCatagory LIKE :keyword)");
        $this->db->bind('keyword', "%$keyword%");
        return $this->db->resultSet();
    }

    public function getCatagory($keyword){

        $this->db->query("SELECT DISTINCT Catagory.Catagory FROM Catagory INNER JOIN Article ON Catagory.ID_Catagory=Article.ID_Catagory WHERE Catagory LIKE :keyword");
        $this->db->bind('keyword', "%$keyword%");
        return $this->db->resultSet();

    }

    public function getAllArticleById($id){

        $this->db->query("SELECT Article.ID_Article, Article.Title, Users.Name, Catagory.Catagory, SubCatagory.SubCatagory, Article.Article, Article.Attachment, Article.DateCreate, Article.DateUpdated FROM Article INNER JOIN Catagory ON Catagory.ID_Catagory=Article.ID_Catagory INNER JOIN SubCatagory ON Article.ID_SubCatagory=SubCatagory.ID_SubCatagory INNER JOIN Users ON Article.ID_Users=Users.ID_Users WHERE ID_Article=:id");
        $this->db->bind('id', $id);
        return $this->db->single();

    }

    public function getInfoComment($id){

        $this->db->query("SELECT Comment.ID_Comment, Users.Name, Users.Email ,Comment.ID_Article, Comment.Comment, Comment.Question, Comment.DateComment FROM Comment INNER JOIN Users ON Users.ID_Users=Comment.ID_Users WHERE ID_Article=:id");
        $this->db->bind('id',$id);
        return $this->db->resultSet();
    }

    public function insertComment($iduser, $idarticle, $data){

        $this->db->query("INSERT INTO Comment VALUES('',:ID_User,:ID_Article,:Comment,:Question,NOW())");
        $this->db->bind('ID_User', $iduser);
        $this->db->bind('ID_Article', $idarticle);
        $this->db->bind('Comment', $data['valComment']);
        $this->db->bind('Question', $data['inlineRadioOptions']);

        $this->db->execute();

        return $this->db->rowCount();

    }

    

}