<?php

class User_model{

    private $table = 'Users';
    private $db;
    private $mail;

    public function __construct(){

        $this->db = new Database;
        $this->mail = new Mailer;

    }

    public function validasiLogin($data){

        $this->db->query('SELECT * FROM '.$this->table);
        $dataUSERDB = $this->db->resultSet();
        
        foreach ($dataUSERDB as $user){

            if ($user['Email'] == strtoupper($data['Email']) && $user['Password'] == md5($data['Password'])){

                return $user;

            }else {

                $check = false;

            }

        }

        return $check;

    }

    public function changePassword($id,$val){

        $this->db->query("UPDATE $this->table SET Password=:valPassword WHERE (ID_Users = :id AND Password=:rePassword ); ");
        $this->db->bind('valPassword',md5($val['valPassword']));
        $this->db->bind('id',$id);
        $this->db->bind('rePassword',md5($val['rePassword']));
        $this->db->execute();

        return $this->db->rowCount();


    }

    public function changeProfile($id,$val){

        $this->db->query("UPDATE $this->table SET Name=:valName WHERE (ID_Users = :id AND Email=:Email)");
        $this->db->bind('valName',strtoupper($val['Name']));
        $this->db->bind('Email',strtoupper($val['Email']));
        $this->db->bind('id',$id);
        $this->db->execute();

        return $this->db->rowCount();


    }

    public function sendMailChangePass($email){

        $this->db->query("SELECT*FROM Users WHERE Email=$email");
        $Take['Data'] = $this->db->resultSet();

        
        
        if ($this->mail->sendMail($email, md5($Take['Data']['Password'])) != Null){

            $Code = $this->mail->sendMail($email['Email'], md5($Take['Data']['Password']));
            return $Code;

        }else {

            return "Gagal";

        }

    }

    // public function dataUSER($data = []){

    //     $ID_User = $data['ID_Users'];
    //     $Name = $data['Name'];
    //     $Email = $data['Email'];
    //     $GrantPrivilages = $data['GrantPrivilages'];


    // }


}