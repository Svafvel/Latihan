<!-- Awal Header -->

<div class="container">
    <div class="header">
        <p>
            <strong>
                <a href="">Knowladge Base</a>
            </strong>
        </p>
        <p>
            <strong>
                <a href="<?= BASEURL; ?>">Back to Login</a>
            </strong>
        </p>
    </div>
</div>


<!-- Akhir Header -->

<!-- Form Login -->

<div class="container">
    <div class="kotak-resetpassword">
        <div class="header-resetpassword">
            <p>Password Recovery</p>
        </div>
        <form action="<?= BASEURL; ?>login/Goreset_password" method="POST">
            <div class="row justify-content-center">
                <div class="col-auto">
                    <p class="note">Enter your registered email address and we will send you instructions to reset your password.</p>
                </div>
            </div>
            <div class="form-group row justify-content-center">
                <label for="inputEmail" class="col-sm-2 col-form-label">Email Address<span style="color:red;"> * </span></label>
                <div class="col-sm-6">
                    <input type="Email" class="form-control" id="inputEmail" placeholder="Email" name="Email" required>
                </div>
            </div>
            <div class="form-group row justify-content-center" style="margin-left:50%;">
                <div class="col-auto">
                    <button type="button" class="btn btn-primary" name="resetPassword">Reset Password</button>
                </div>
            </div>
        </form>
    </div>
</div>


<!-- Akhir Form Login -->

<!-- Footer -->

<div class="footer">
    <p>AndikaKurniawan&copy;2019</p>
</div>

<!-- Akhir Footer -->