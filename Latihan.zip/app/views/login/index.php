<!-- Awal Header -->

<div class="container">
    <div class="header">
        <p>
            <strong>
                <a href="">Knowladge Base</a>
            </strong>
        </p>
    </div>
</div>


<!-- Akhir Header -->

<!-- Form Login -->

<div class="container">
    <div class="kotak-login">
        <div class="header-login">
            <p>Login</p>
        </div>
        <form action="<?= BASEURL; ?>login/validasiLogin" method="POST">
            <div class="form-group row justify-content-center">
                <div class="col-auto">
                    <Strong style="color:red;">

                        <?php global $Salah;

                        echo $Salah; ?>

                    </Strong>
                </div>
            </div>
            <div class="form-group row justify-content-center">
                <label for="inputEmail" class="col-sm-1 col-form-label">Email</label>
                <div class="col-sm-6">
                    <input type="Email" class="form-control" id="inputEmail" placeholder="Email" name="Email">
                </div>
            </div>
            <div class="form-group row justify-content-center">
                <label for="inputPassword" class="col-sm-1 col-form-label">Password</label>
                <div class="col-sm-6">
                    <input type="Password" class="form-control" id="inputPassword" placeholder="Password" name="Password">
                </div>
            </div>
            <div class="form-group row justify-content-center" style="margin-left:-25%;">
                <div class="col-auto">
                    <p><a href="<?= BASEURL; ?>login/reset_password">Forgot Yout Password?</a></p>
                </div>
            </div>
            <div class="form-group row justify-content-center" style="margin-left:50%;">
                <div class="col-auto">
                    <button type="submit" class="btn btn-primary" name="login">Login</button>
                </div>
            </div>
        </form>
        <div class="Note">
            <ul>Note : For demo purposes, use the following logins : </ul>
            <ul>
                <li>User Login</li>
                <li>Email : user@gmail.com</li>
                <li>Password : password</li>
            </ul>
            <ul>
                <li>Author Login</li>
                <li>Email : author@gmail.com</li>
                <li>Password : password</li>
            </ul>
            <ul>
                <li>Editor Login</li>
                <li>Email : editor@gmail.com</li>
                <li>Password : password</li>
            </ul>
        </div>
    </div>
</div>


<!-- Akhir Form Login -->

<!-- Footer -->

<div class="footer">
    <p>AndikaKurniawan&copy;2019</p>
</div>

<!-- Akhir Footer -->