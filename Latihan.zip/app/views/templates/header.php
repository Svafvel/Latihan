<!doctype html>
<html lang="en">
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


<link rel="stylesheet" href="<?= BASEURL;?>vendor/css/bootstrap.css">
<link rel="stylesheet" href="<?php echo BASEURL.'/vendor/'.strtolower($data['judul']);?>/css/style.css">

<title><?= $data['judul']; ?></title>
</head>
<body>
  