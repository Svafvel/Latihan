
<script src="<?= BASEURL;?>vendor/jquery/jquery.js"></script>
<script src="<?= BASEURL;?>vendor/popper/popper.js"></script>
<script src="<?= BASEURL;?>vendor/js/bootstrap.js"></script>
<script src="<?php echo BASEURL.'/vendor/'.strtolower($data['judul']);?>/js/script.js"></script>
</body>
</html>