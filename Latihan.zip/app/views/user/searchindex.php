
<?php foreach ($data['getCatagory'] as $Catagory) : ?>

    <?php if (empty($Catagory) != true) : ?>

    <tr>
        <td class="bg-light"></td>
        <td class="bg-light">
            <button id="btn" type="button" class="badge badge-primary" onclick="popup('<?= $Catagory['Catagory'] ?>')">-</button> <?= $Catagory['Catagory']; ?>
        </td>
        <td class="bg-light"></td>
        <td class="bg-light"></td>
        <td class="bg-light"></td>
    </tr>

    <?php endif; ?>
    
    <?php $i = 1;
    foreach ($data['allarticle'] as $allArticle) : ?>

        <?php if ($Catagory['Catagory'] == $allArticle['Catagory']) : ?>

            <tr class="<?= $allArticle['Catagory']; ?>" style="display : ">
                <td><?= $i; ?></td>
                <td></td>
                <td><?= $allArticle['SubCatagory']; ?></td>
                <td><?= $allArticle['Title']; ?></td>
                <td><a href="<?= BASEURL; ?>user/detail/<?= $allArticle['ID_Article']; ?>" class="badge badge-primary">details</a></td>
            </tr>
        <?php endif; ?>

        <?php $i++;
    endforeach; ?>

<?php endforeach; ?>
