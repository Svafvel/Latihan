<!-- Awal Header -->

<div class="container">
    <div class="header">
        <div class="row">
            <div class="col align-self-start">
                <p><strong><a href="">Knowladge Base</a></strong></p>
            </div>
            <div class="col align-self-end">
                <p class="logout"><strong><a href="<?= BASEURL; ?>">Logout</a></strong></p>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <p class="hal"><strong><a href="">Halaman <?= $data['judul']?></a></strong></p>
            </div>
        </div>
    </div>
</div>


<!-- Akhir Header -->

<!-- Article Detail -->

<div class="container">
    <div class="kotak-article">
        <div class="row">
            <div class="col-sm-3 box">
                <div class="header-article">
                    <p>Articles</p>
                </div>
                <div class="">
                    <ol class="text-center"><a href="<?= BASEURL; ?>user">All Articles</a></ol>
                </div>
                <br>
                <div class="header-article">
                    <p>Settings</p>
                </div>
                <div class="">
                    <ol class="text-center"><a href="<?= BASEURL; ?>user/profile">Profile</a></ol>
                    <ol class="text-center"><a href="<?= BASEURL; ?>user/change_password">Change Password</a></ol>
                </div>
            </div>
            <div class="col-sm-9 box">
                <div class="header-allArticle">
                    <p>Article Detail</p>
                </div>
                <table class="table">
                    <tbody>
                        <tr>
                            <td>Title</td>
                            <td><?= $data['allarticle']['Title'];?></td>
                        </tr>
                        <tr>
                            <td>Author</td>
                            <td><?= $data['allarticle']['Name'];?></td>
                        </tr>
                        <tr>
                            <td>Catagory</td>
                            <td><?= $data['allarticle']['Catagory'];?></td>
                        </tr>
                        <tr>
                            <td>Sub Catagory</td>
                            <td><?= $data['allarticle']['SubCatagory'];?></td>
                        </tr>
                        <tr>
                            <td>Article</td>
                            <td><?= $data['allarticle']['Article'];?></td>
                        </tr>
                        <tr>
                            <td>Attachment</td>
                            <td><?= $data['allarticle']['Attachment'];?></td>
                        </tr>
                        <tr>
                            <td colspan="2">Create : <?= $data['allarticle']['DateCreate']?> | Updated : <?= $data['allarticle']['DateUpdated']?></td>
                        </tr>
                        <tr>
                            <td colspan="2" class="text-center"><a href="<?= BASEURL; ?>user" class="btn btn-primary">Back</a></td>
                        </tr>
                    </tbody>
                </table>
                <div class="header-allArticle">
                    <p>Comment</p>
                </div>
                <form action="<?= BASEURL; ?>user/insertComment/<?= $_SESSION['user']; ?>/<?= $data['allarticle']['ID_Article']; ?>" method="POST">
                    <div class="row form-group">
                        <div class="col-auto">
                            <label for="Help">Was this Helpful ? <span style="color:red;">*</span></label>
                        </div>
                        <div class="col-auto">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="Help" value="Yes">
                                <label class="form-check-label" for="inlineRadio1">Yes</label>
                                </div>
                                <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="Help" value="No">
                                <label class="form-check-label" for="inlineRadio2">No</label>
                                </div>
                                <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="Help" value="Somewhat">
                                <label class="form-check-label" for="inlineRadio3">Somewhat</label>
                            </div>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-auto">
                            <label for="valComment">Additional Comments</label>
                            <textarea class="form-control" name="valComment" id="valComment" cols="57" rows="5"></textarea>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col offset-7">
                            <button type="submit" class="btn btn-primary">Kirim</button>
                        </div>
                    </div>
                </form>
                <?php foreach ($data['allInfoComment'] as $allInfoComment) : ?>
                <br>
                <div class="row">
                    <div class="col-auto">
                        Comment by <a href="mailto:<?= $allInfoComment['Email']; ?>"><?= $allInfoComment['Name']; ?></a> on <?= $allInfoComment['DateComment']; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-auto">
                        <?= $allInfoComment['Comment']; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-auto">
                        Helpful ? <?= $allInfoComment['Question']; ?>
                    </div>
                </div>

                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>


<!-- Akhir Article Detail -->

<!-- Footer -->

<div class="footer">
    <p>AndikaKurniawan&copy;2019</p>
</div>

<!-- Akhir Footer -->