<!-- Awal Header -->

<div class="container">
    <div class="header">
        <div class="row">
            <div class="col align-self-start">
                <p><strong><a href="">Knowladge Base</a></strong></p>
            </div>
            <div class="col align-self-end">
                <p class="logout"><strong><a href="<?= BASEURL; ?>">Logout</a></strong></p>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <p class="hal"><strong><a href="">Halaman <?= $_SESSION['GrantPrivilages'];?></a></strong></p>
            </div>
        </div>
    </div>
</div>


<!-- Akhir Header -->

<!-- Form Article -->

<div class="container">
    <div class="kotak-article">
        <div class="row">
            <div class="col-sm-3 box">
                <div class="header-article">
                    <p>Articles</p>
                </div>
                <div class="">
                    <ol class="text-center"><a href="">All Articles</a></ol>
                </div>
                <br>
                <div class="header-article">
                    <p>Settings</p>
                </div>
                <div class="">
                    <ol class="text-center"><a href="<?= BASEURL; ?>user/profile">Profile</a></ol>
                    <ol class="text-center"><a href="<?= BASEURL; ?>user/change_password">Change Password</a></ol>
                </div>
            </div>
            <div class="col-sm-9 box">
                <div class="header-allArticle">
                    <p>All Article</p>
                </div>
                <!-- <div class="Search-box hide">
                    <input type="text" name="SearchCatagory" class="SearchCatagory col-sm-6 form-control" placeholder="Search Catagory" autocomplete="off">
                </div> -->
                <div class="Search-box form-group">
                    <input type="text" name="Search" class="Search col-sm-6 form-control" placeholder="Search Article" autocomplete="off">
                </div>
                <table class="table">
                    <thead>
                        <tr class="table-primary">
                            <th scope="col">No</th>
                            <th scope="col">Catagory</th>
                            <th scope="col">Sub Catagory</th>
                            <th scope="col">Title</th>
                            <th scope="col">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bot">
                        <?php foreach ($data['allcatagory'] as $allCatagory) : ?>
                        <tr>
                            <td class="bg-light"></td>
                            <td class="bg-light">
                                <button id="btn" type="button" class="badge badge-primary" onclick="popup('<?= $allCatagory['Catagory'] ?>')">-</button> <?= $allCatagory['Catagory']; ?>
                            </td>
                            <td class="bg-light"></td>
                            <td class="bg-light"></td>
                            <td class="bg-light"></td>
                        </tr>
                            <?php $i = 1;
                            foreach ($data['allarticle'] as $allArticle) :?>

                                <?php if ($allCatagory['Catagory'] == $allArticle['Catagory']) : ?>

                                <tr class="<?= $allArticle['Catagory']; ?>" style="display : ">
                                    <td><?= $i; ?></td>
                                    <td></td>
                                    <td><?= $allArticle['SubCatagory'];?></td>
                                    <td><?= $allArticle['Title'];?></td>
                                    <td><a href="<?= BASEURL; ?>user/detail/<?= $allArticle['ID_Article'];?>"  class="badge badge-primary">details</a></td>
                                </tr>
                                <?php endif; ?>
                                
                            <?php $i++;
                            endforeach; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- Akhir Article -->

<!-- Footer -->

<div class="footer">
    <p>AndikaKurniawan&copy;2019</p>
</div>

<!-- Akhir Footer -->