<!-- Awal Header -->

<div class="container">
    <div class="header">
        <div class="row">
            <div class="col align-self-start">
                <p><strong><a href="">Knowladge Base</a></strong></p>
            </div>
            <div class="col align-self-end">
                <p class="logout"><strong><a href="<?= BASEURL; ?>">Logout</a></strong></p>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <p class="hal"><strong><a href="">Halaman <?= $data['judul']?></a></strong></p>
            </div>
        </div>
    </div>
</div>


<!-- Akhir Header -->

<!-- Change Password -->

<div class="container">
    <div class="kotak-profile">
        <div class="row">
            <div class="col-sm-3 box">
                <div class="header-profile">
                    <p>Articles</p>
                </div>
                <div class="">
                    <ol class="text-center"><a href="<?= BASEURL; ?>user">All Articles</a></ol>
                </div>
                <br>
                <div class="header-profile">
                    <p>Settings</p>
                </div>
                <div class="">
                    <ol class="text-center"><a href="">Profile</a></ol>
                    <ol class="text-center"><a href="<?= BASEURL; ?>user/change_password">Change Password</a></ol>
                </div>
            </div>
            <div class="col-sm-9 box">
                <div class="header-allProfile">
                    <p>Article Detail</p>
                </div>
                <p>Once you change your personal data, you will be prompted to login again.</p>
                <form action="<?= BASEURL; ?>user/changeProfile/<?= $_SESSION['user']; ?>" method="POST">
                    <div class="row form-group">
                        <label for="Name" class="col-sm-2 form-label">Name<span style="color:red;">*</span></label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="Name" name="Name" required>
                        </div>
                    </div>
                    <div class="row form-group">
                        <label for="Email" class="col-sm-2 form-label">Email<span style="color:red;">*</span></label>
                        <div class="col-sm-6">
                            <input type="Email" class="form-control" id="Email" name="Email" required>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-auto offset-sm-7" style="margin-left:54%;">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- Akhir Change Password-->

<!-- Footer -->

<div class="footer">
    <p>AndikaKurniawan&copy;2019</p>
</div>

<!-- Akhir Footer -->