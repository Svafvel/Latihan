<!-- Awal Header -->

<div class="container">
    <div class="header">
        <div class="row">
            <div class="col align-self-start">
                <p><strong><a href="">Knowladge Base</a></strong></p>
            </div>
            <div class="col align-self-end">
                <p class="logout"><strong><a href="<?= BASEURL; ?>">Logout</a></strong></p>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <p class="hal"><strong><a href="">Halaman <?= $data['judul']?></a></strong></p>
            </div>
        </div>
    </div>
</div>


<!-- Akhir Header -->

<!-- Change Password -->

<div class="container">
    <div class="kotak-changePassword">
        <div class="row">
            <div class="col-sm-3 box">
                <div class="header-changePassword">
                    <p>Articles</p>
                </div>
                <div class="">
                    <ol class="text-center"><a href="<?= BASEURL; ?>user">All Articles</a></ol>
                </div>
                <br>
                <div class="header-changePassword">
                    <p>Settings</p>
                </div>
                <div class="">
                    <ol class="text-center"><a href="<?= BASEURL; ?>user/profile">Profile</a></ol>
                    <ol class="text-center"><a href="">Change Password</a></ol>
                </div>
            </div>
            <div class="col-sm-9 box">
                <div class="header-allChangePassword">
                    <p>Article Detail</p>
                </div>
                <p>Once you change your password, you will be prompted to login again.</p>
                <form action="<?= BASEURL; ?>user/changePassword/<?= $_SESSION['user']; ?>" method="POST">
                    <div class="row form-group">
                        <label for="CurrentPassword" class="col-sm-2 form-label">Current Password<span style="color:red;">*</span></label>
                        <div class="col-sm-6">
                            <input type="password" class="form-control" id="CurrentPassword" name="rePassword" required>
                        </div>
                    </div>
                    <div class="row form-group">
                        <label for="NewPassword" class="col-sm-2 form-label">New Password<span style="color:red;">*</span></label>
                        <div class="col-sm-6">
                            <input type="password" class="NewPassword form-control" id="NewPassword" required>
                        </div>
                    </div>
                    <div class="row form-group">
                        <label for="ConfirmPassword" class="col-sm-2 form-label">Confirm Password<span style="color:red;">*</span></label>
                        <div class="col-sm-6">
                            <input type="password" class="ConfirmPassword form-control" id="ConfirmPassword" name="valPassword" required>
                            <p class="Note"></p>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-auto offset-sm-7" style="margin-left:54%;">
                            <button type="submit" class="btn btn-primary btn-update" disabled>Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- Akhir Change Password-->

<!-- Footer -->

<div class="footer">
    <p>AndikaKurniawan&copy;2019</p>
</div>

<!-- Akhir Footer -->