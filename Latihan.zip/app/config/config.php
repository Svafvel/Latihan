<?php

define('BASEURL','http://localhost/LatihanPHP/LatihanMVC/public/');

// Database

define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','Article');

//Mailer

define('EMAIL','arexmint@gmail.com');
define('PASS','Re42080655100');